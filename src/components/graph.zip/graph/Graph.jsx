import React, { useState } from 'react'
import "./graph.css"
import Fetch from '../../resources/fetch'
import apiRoutes from '../../resources/apiUrls'

export default function Graph() {
  const [image, setImage] = useState(null);

  const generateGraph = async (e) => {
    e?.preventDefault();
    try {
      const response = await Fetch(apiRoutes.GRAPH, "post", JSON.stringify({}), "json", "blob");
      const url = URL.createObjectURL(response);
      setImage(url);
    } catch (error) {
      console.error('Error fetching the graph:', error);
    }
  };

  return (
    <div className="App">
      <button onClick={generateGraph}>Get Graph</button>
      {image ? <img src={image} alt="Graph" /> : <p>Loading...</p>}
    </div>
  );
}
